package Composite_Design_Pattern;

public interface Components {
	void Screen();

}
